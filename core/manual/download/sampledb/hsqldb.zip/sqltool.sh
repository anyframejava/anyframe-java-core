#!/bin/bash
java -jar hsqldb-1.8.0.10.jar --inlineRc URL=jdbc:hsqldb:hsql://localhost/sampledb,USER=sa 
