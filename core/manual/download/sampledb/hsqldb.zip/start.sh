#!/bin/bash

java -cp ./hsqldb-1.8.0.10.jar org.hsqldb.Server -database.0 sampledb -dbname.0 sampledb
